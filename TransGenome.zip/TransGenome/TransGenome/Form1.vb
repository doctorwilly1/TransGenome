﻿
Public Class Form1
    Private Sub RichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RichTextBox1.TextChanged
        Dim TestBinary As String
        TestBinary = StrToBinary(TestBinary)
        BinaryLabel.Text = TestBinary
    End Sub
    Function StrToBinary(ByVal inputStr As String) As String

        Dim lValue As Integer
        Dim BinaryArr() As String
        Dim BinaryStr As String = ""  'This is fine 
        Dim i As Integer

        inputStr = RichTextBox1.Text
        If RichTextBox1.Text = "" Then
            RichTextBox1.Text = "0"
        Else
            lValue = Asc(inputStr)
            i = 0

            ReDim BinaryArr(i)

            While lValue <> 0
                ReDim Preserve BinaryArr(i)
                BinaryArr(i) = lValue Mod 2

                lValue = lValue \ 2
                i = i + 1
            End While


            If UBound(BinaryArr) >= 0 Then
                For i = 0 To UBound(BinaryArr)
                    BinaryStr = BinaryArr(i) & BinaryStr
                Next
                BinaryStr = String.Format("0", 8 - Len(BinaryStr)) & BinaryStr
            End If

            StrToBinary = BinaryStr
        End If
    End Function



End Class
